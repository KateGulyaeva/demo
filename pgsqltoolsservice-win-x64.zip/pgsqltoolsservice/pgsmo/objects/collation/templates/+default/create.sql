{#
 # pgAdmin 4 - PostgreSQL Tools
 #
 # Copyright (C) 2013 - 2017, The pgAdmin Development Team
 # This software is released under the PostgreSQL Licence
 #}
{% if data %}
CREATE COLLATION {{ conn|qtIdent(data.schema, data.name) }}
{# if user has provided lc_collate & lc_type #}
{% if data.lc_collate and data.lc_type %}
    (LC_COLLATE = {{ data.lc_collate|qtLiteral }}, LC_CTYPE = {{ data.lc_type|qtLiteral }});
{% endif %}
{# if user has provided locale only  #}
{% if data.locale %}
    (LOCALE = {{ data.locale|qtLiteral }});
{% endif %}
{# if user has choosed to copy from existing collation #}
{% if data.copy_collation %}
    FROM {{ data.copy_collation }};
{% endif %}
{% if data.owner %}

ALTER COLLATION {{ conn|qtIdent(data.schema, data.name) }}
    OWNER TO {{ conn|qtIdent(data.owner) }};
{% endif %}
{% if data.description %}

COMMENT ON COLLATION {{ conn|qtIdent(data.schema, data.name) }}
    IS {{ data.description|qtLiteral }};
{% endif %}
{% endif %}